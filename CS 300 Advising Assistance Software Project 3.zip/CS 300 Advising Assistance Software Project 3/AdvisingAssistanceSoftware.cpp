//============================================================================
// Name        : AdvisingAssistanceSoftware.cpp
// Author      : Ian Viguera
// Version     : 1.0
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <vector>
#include "CSVparser.hpp"
#include <string>
using namespace std;

// Structure to hold information
struct Course
{
    string number;
    string name;

    vector<string> preRequisites;

    Course() {}
};

struct Node
{
    Course courses;
    Node *left;
    Node *right;

    Node()
    {
        left = nullptr;
        right = nullptr;
    }
    Node(Course aCourse) :
        Node() {
        this->courses = aCourse;
    }
};

// Class for a Binary Search Tree
class BinarySearchTree
{
private:
    Node *root;

    void addNode(Node *node, Course courses);
    void printSchedule(Node* node);
    void printCourseInformation(Node* node, string number);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void recurseNode(Node* node);
    void loadCourses(Course course);
    int preRequisites(Course course);
    void printSchedule();
    void printCourseInformation(string number);
};

// Constructor
BinarySearchTree::BinarySearchTree()
{
    root = nullptr;
}


// Destructor
BinarySearchTree::~BinarySearchTree()
{
    recurseNode(root);
}

// Delete nodes recoursively
void BinarySearchTree::recurseNode(Node* node)
{
    if (node)
    {
        recurseNode(node->left);
        recurseNode(node->right);
        delete node;
    }
}

// Loads course nodes to binary tree
void BinarySearchTree::loadCourses(Course courses)
{
    if (root == nullptr)
    {
        root = new Node(courses);
    }
    else
    {
        this->addNode(root, courses);
    }
}


// Function that outputs prerequisites
int BinarySearchTree::preRequisites(Course courses)
{
    int count = 0;

    for (unsigned int i = 0; i < courses.preRequisites.size(); i++)
    {
        if (courses.preRequisites.at(i).length() > 0)
        {
            count++;
        }
    }
    return count;
}


// Pass root to its method
void BinarySearchTree::printSchedule()
{
    this->printSchedule (root);
}


// Passes root to method to return its number
void BinarySearchTree::printCourseInformation(string number)
{
    this->printCourseInformation(root, number);
}


// 
void BinarySearchTree::addNode(Node* node, Course courses)
{
    if (node->courses.number.compare(courses.number) > 0)
    {
        if (node->left == nullptr)
        {
            node->left = new Node(courses);
        }
        else
        {
            this->addNode(node->left, courses);
        }
    }
    else
    {
        if (node->right == nullptr)
        {
            node->right = new Node(courses);
        }
        else
        {
            this->addNode(node->right, courses);
        }
    }
}


// Add node to binary tree
void BinarySearchTree::printSchedule(Node* node)
{
    if (node != nullptr)
    {
        printSchedule(node->left);
        cout << node->courses.number << ", " << node->courses.name << endl;
        printSchedule(node->right);
    }
    return;
}


// Load courses in order
void BinarySearchTree::printCourseInformation(Node* curNode, string number)
{
    while (curNode != nullptr)
    {
        if (curNode->courses.number.compare(number) == 0)
        {
            cout << endl;
            cout << curNode->courses.number << ", " << curNode->courses.name << endl;

            unsigned int size = preRequisites(curNode->courses);

            cout << "Prerequisites: ";


            for (unsigned int i = 0; i < size; i++)
            {
                cout << curNode->courses.preRequisites.at(i);

                if (i == 0) 
                {
                    cout << "There are no prerequisites required" << endl;
                    return;
                }
            }
        }

        else if (curNode->courses.number.compare(number) < 0)
        {
            curNode = curNode->left;
        }

        else
        {
            curNode = curNode->right;
        }


        cout << "Not found" << endl;
    }
}


// Loads courses based on user input
bool loadCourses(string csvPath, BinarySearchTree* courseSearchTree)
{
    try
    {
        ifstream myFile(csvPath);

        if (myFile.is_open())
        {
            while (!myFile.eof())
            {
                vector<string> info;
                string data;

                getline(myFile, data);

                while (data.length() > 0)
                {
                    unsigned int spacer = data.find(',');

                    if (spacer < 100)
                    {
                        info.push_back(data.substr(0, spacer));
                        data.erase(0, spacer + 1);
                    }

                    else
                    {
                        info.push_back(data.substr(0, data.length()));
                        data = "";
                    }
                }


                Course courses;
                courses.number = info[0];
                courses.name = info[1];

                for (unsigned int i = 2; i < info.size(); i++)
                {
                    courses.preRequisites.push_back(info[i]);
                }

                courseSearchTree->loadCourses(courses);
            }

            myFile.close();
            return true;

        }
    }
    catch (csv:: Error& e) 
    {
        std::cerr << e.what() << std::endl;
    }
    return false;
}

// Main function
int main(int argc, char *argv[])
{
    string csvPath, courseId;
    switch (argc)
    {
    case 2:
        csvPath = argv[1];
        break;

    case 3:
        csvPath = argv[1];
        courseId = argv[2];
        break;

    default:
        csvPath = "";
        break;
    }

    BinarySearchTree* courses = nullptr;
    string choice = "0";
    int userChoice = choice[0] - '0';


    // Menu construction and controller

    while (userChoice != 9)
    {
        cout << "Welcome to the course planner" << endl;
        cout << endl;

        cout << "  1. Load Data Structure." << endl;
        cout << "  2. Print Course List." << endl;
        cout << "  3. Print Course." << endl;
        cout << "  9. Exit" << endl;
        cout << "What would you like to do? ";
        
        cin >> choice;


        bool loaded = 1;

        switch (userChoice)
        {
        case 1:

            if (courses == nullptr)
            {
                courses = new BinarySearchTree();
            }

            if (csvPath.length() == 0)
            {
                cout << "Enter File Name: " << endl;
                cin >> csvPath;
            }

            if (loaded)
            {
                cout << "Files Loaded Successfully" << endl;
            }

            else
            {
                cout << "Unable to open file" << endl;
                csvPath = "";
                break;
            }

        case 2:

            if (courses != nullptr && loaded)
            {
                cout << "Here is a sample schedule: " << endl;
                courses->printSchedule();
                cout << endl;
            }
            else
            {
                cout << "No data found on file" << endl;
                break;
            }

        case 3:

            if (courses != nullptr && loaded)
            {
                if (courseId.length() == 0)
                {
                    cout << "What course do you want to know about?";
                    cin >> courseId;
                    
                    for (auto& userChoice : courseId)
                    {
                        toupper(userChoice);
                    }
                }

                courses->printCourseInformation(courseId);
                cout << endl;
            }
            else
            {
                cout << "No data found on file" << endl;
                courseId = "";
                break;
            }

        default:

            if (userChoice != 9)
            {
                cout << "Invalid Input" << endl;
                break;
            }

        }
    }

    cout << "Thank you for using the course planner!" << endl;
    return 0;
}
