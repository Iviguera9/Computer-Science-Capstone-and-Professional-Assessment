// Connect Appointment Function with Database
package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.entity.Appointment;
import com.entity.Specialist;

public class AppointmentDao {

	private Connection dbs;
	
	public AppointmentDao(Connection dbs) {
		
		super();
		this.dbs = dbs;
	}
	
	public boolean addAppointment(Appointment a) {
		
		boolean f = false;
		
		 // insert data into database table (appointment)
		try {
			String sql = "INSERT INTO appointment(userId, doctorId, fullName, gender, age, appointmentDate, email, number, symptom) values(?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement statement = dbs.prepareStatement(sql);
			statement.setInt(1, a.getUserId());
			statement.setInt(2, a.getDoctorId());
			statement.setString(3, a.getFullName());
			statement.setString(4, a.getGender());
			statement.setString(5, a.getAge());
			statement.setString(6, a.getAppointmentDate());
			statement.setString(7, a.getEmail());
			statement.setString(8, a.getNumber());
			statement.setString(9, a.getSymptom());
			
			int i = statement.executeUpdate();
			
			if(i == 1) {
				
				f = true;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return f;
		
	}
	
	// List that holds recorded appointments
	public List<Appointment>getAllappointments(int userId){
		List<Appointment>list = new ArrayList<Appointment>();
		
		 String sql = "SELECT * FROM appointment WHERE userId = ?"; // Specify columns explicitly

		    try (PreparedStatement statement = dbs.prepareStatement(sql);
		         ResultSet result = statement.executeQuery()) {

		        // Iterating through the list
		        while (result.next()) {
		            Appointment a = new Appointment();
		            a.setUserId(result.getInt("userId"));
		            a.setDoctorId(result.getInt("doctorId"));
		            a.setFullName(result.getString("fullName"));
		            a.setGender(result.getString("gender"));
		            a.setAge(result.getString("age"));
		            a.setAppointmentDate(result.getString("appointmentDate"));
		            a.setEmail(result.getString("email"));
		            a.setNumber(result.getString("number"));
		            a.setSymptom(result.getString("symptom"));
		            list.add(a);
		        }

		    } 
		    catch (SQLException e) {
		        Logger.getLogger(SpecialistDao.class.getName()).log(Level.SEVERE, "Error fetching specialists", e);
		            }
		
		return list;
	}
}
