// Connect Specialist Function with Database
package com.dao;

import java.sql.PreparedStatement;  
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.entity.Specialist;

import java.sql.Connection;
import java.util.logging.Logger;
import java.util.logging.Level;
public class SpecialistDao {

	private Connection dbs;
	
	public SpecialistDao(Connection dbs) {
		super();
		this.dbs = dbs;
	}
	
	public boolean addSpecialist(String specialistName) {
	    boolean f = false;
	    
	
	    // insert data into database table (specialist)
	    if (specialistName == null || specialistName.trim().isEmpty()) {
	        return false;  
	    }

	    String sql = "INSERT INTO specialist(specialistName) VALUES(?)";
	    
	    try (PreparedStatement statement = dbs.prepareStatement(sql)) {
	       
	        statement.setString(1, specialistName);
	        
	       
	        int i = statement.executeUpdate();
	        if (i == 1) {
	            f = true;  
	        }

	    } 
	    catch (Exception e) {
	       
	        e.printStackTrace(); 
	        }

	    return f;
	}

	// List that holds recorded specialists
	public List<Specialist> getAllSpecialist() {
	    List<Specialist> list = new ArrayList<>();
	    String sql = "SELECT id, specialistName FROM specialist"; 
	    try (PreparedStatement statement = dbs.prepareStatement(sql);
	         ResultSet result = statement.executeQuery()) {

	        // Iterating through the list
	        while (result.next()) {
	            Specialist specialist = new Specialist();
	            specialist.setId(result.getInt("id"));
	            specialist.setSpecialistName(result.getString("specialistName"));
	            list.add(specialist);
	        }

	    } 
	    catch (SQLException e) {
	        Logger.getLogger(SpecialistDao.class.getName()).log(Level.SEVERE, "Error fetching specialists", e);
	            }

	    return list;
	}

}
