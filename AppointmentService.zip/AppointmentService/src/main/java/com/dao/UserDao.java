// Connect User Function with Database
package com.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.entity.User;

public class UserDao {
	
	private Connection dbs;

	public UserDao(Connection dbs) {
		super();
		this.dbs = dbs;
	}
	
	public boolean UserRegister(User u) {
		boolean f = false;
		
		// Insert data into database table (user_contact)
		try {
			String sql = "insert into user_contact(name,email,password) values(?,?,?)";
			
			PreparedStatement statement = dbs.prepareStatement(sql);
			statement.setString(1, u.getName());
			statement.setString(2, u.getEmail());
			statement.setString(3, u.getPassword());
			
			int update = statement.executeUpdate();
			
			if(update == 1) {
				f = true;
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return f;
	}
	
	// Access stored data in database
	public User login(String email, String password) {
		User u = null;
		try {
			String sql = "SELECT * FROM user_contact WHERE email = ? and password = ?";
			PreparedStatement statement = dbs.prepareStatement(sql);
			statement.setString(1, email);
			statement.setString(2,password);
			
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				
				u = new User();
				u.setId(result.getInt("id"));
				u.setName(result.getString("name"));
				u.setEmail(result.getString("email"));
				u.setPassword(result.getString("password"));
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	return u;
		
	}
}
