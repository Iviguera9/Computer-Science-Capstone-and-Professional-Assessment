// Connect Doctor Function with Database
package com.dao;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.entity.Doctor;

public class DoctorDao {

	private Connection dbs;
	
	public DoctorDao(Connection dbs) {
		super();
		this.dbs = dbs;
	}
	
	public boolean registerDoctor(Doctor d) {
	    boolean f = false;
	    
	    // insert data into database table (doctors)
	    String sql = "INSERT INTO doctors (fullName, dob, specialist, email, password) VALUES (?, ?, ?, ?, ?)";

	    try (PreparedStatement statement = dbs.prepareStatement(sql)) {
	        
	        // Setting parameters for the prepared statement
	        statement.setString(1, d.getFullName());
	        statement.setString(2, d.getDob());
	        statement.setString(3, d.getSpecialist());
	        statement.setString(4, d.getEmail());
	        statement.setString(5, d.getPassword());

	      
	        int i = statement.executeUpdate();
	        if (i == 1) {
	            f = true; 
	        }

	    } 
	    catch (Exception e) {
	      
	        e.printStackTrace(); 
	        }

	    return f;
	}

	// List that holds recorded doctors
	public List<Doctor> getAllDoctors() {
		
		List<Doctor> list = new ArrayList<Doctor>();
		Doctor d = null;
		
		String sql="SELECT * FROM doctors ORDER BY id DESC";
		
		try(PreparedStatement statement = dbs.prepareStatement(sql);
			ResultSet result = statement.executeQuery()
			) {
			
			
			while(result.next()) {
				
				d = new Doctor();
				d.setId(result.getInt("id"));
				d.setFullName(result.getString("fullName"));
				d.setDob(result.getString("dob"));
				d.setSpecialist(result.getString("specialist"));
				d.setEmail(result.getString("email"));
				d.setPassword(result.getString("password"));
				list.add(d);
			}
		}
		catch (SQLException e) {
	     
	        Logger.getLogger(DoctorDao.class.getName()).log(Level.SEVERE, "Error fetching doctors", e);
	    }
		return list;
	}
	
	// Get Doctor's Id
	public Doctor getDoctorId(int id) {
		
		Doctor d = null;
		String sql="SELECT * FROM doctors WHERE id = ?";
		
		try (PreparedStatement statement = dbs.prepareStatement(sql)){
				statement.setInt(1, id);
			
			try (ResultSet result = statement.executeQuery()){
			
			if(result.next()) {
				
				d = new Doctor();
				d.setId(result.getInt("id"));
				d.setFullName(result.getString("fullName"));
				d.setDob(result.getString("dob"));
				d.setSpecialist(result.getString("specialist"));
				d.setEmail(result.getString("email"));
				d.setPassword(result.getString("password"));
				
			}
		}
	}
		catch(Exception e) {
			
			e.getStackTrace();
		}
		return d;
	}
	
	// Update Doctor
	public boolean updateDoctor(Doctor d) {
	    boolean f = false;
	    
	    String sql = "UPDATE doctors SET fullName = ?, dob = ?, specialization = ?, email = ?, password = ? WHERE id = ?";

	    try (PreparedStatement statement = dbs.prepareStatement(sql)) {
	        
	        // Set the values in the PreparedStatement
	        statement.setString(1, d.getFullName());
	        statement.setString(2, d.getDob());
	        statement.setString(3, d.getSpecialist()); 
	        statement.setString(4, d.getEmail());
	        statement.setString(5, d.getPassword()); 
	        statement.setInt(6, d.getId());

	        // Execute the update and check if one row was updated
	        int i = statement.executeUpdate();
	        
	        if (i == 1) {
	            f = true; 
	        }

	    } catch (Exception e) {
	       
	        e.printStackTrace(); 
	    }

	    return f;
	}

	// Delete Doctor
	public boolean deleteDoctor(int id) {
	    boolean f = false;
	    
	    String sql = "DELETE FROM doctors WHERE id = ?";
	    
	    try (PreparedStatement statement = dbs.prepareStatement(sql)) {
	        
	        statement.setInt(1, id);
	        int i = statement.executeUpdate();

	        if (i == 1) {
	            f = true; 
	        }

	    } 
	    catch (Exception e) {
	      
	    	e.printStackTrace(); 
	    }

	    return f;
	}
}

