package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AppointmentDao;
import com.database.DBConnect;
import com.entity.Appointment;

@WebServlet("/appAppointment")
public class AppointmentServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int userId =  Integer.parseInt(req.getParameter("userId"));
		int doctorId =  Integer.parseInt(req.getParameter("doctorId"));
		String fullName = req.getParameter("fullName");
		String gender = req.getParameter("gender");
		String age = req.getParameter("age");
		String appointmentDate = req.getParameter("appointmentDate");
		String email = req.getParameter("email");
		String number = req.getParameter("number");
		String symptom = req.getParameter("symptom");
		
		
		Appointment a = new Appointment(userId,doctorId, fullName, gender, age, appointmentDate, email, number, symptom);
		
		AppointmentDao dao = new AppointmentDao(DBConnect.getDbs());
		HttpSession session = req.getSession();
		
		if(dao.addAppointment(a)) {
			
			session.setAttribute("sucMsg", "Information Saved");
			resp.sendRedirect("appointment.jsp");
		}
		else {

			session.setAttribute("errMsg", "Something Went Wrong");
			resp.sendRedirect("appointment.jsp");
		}
		
	}

}
