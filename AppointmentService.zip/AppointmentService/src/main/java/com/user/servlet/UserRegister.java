//User Sign up Page
package com.user.servlet;

import java.io.IOException; 

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDao;
import com.database.DBConnect;
import com.entity.User;

@WebServlet("/user_register")
public class UserRegister extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			
			User user = new User(name, email, password);
			
			UserDao  uDao = new UserDao(DBConnect.getDbs());
			
			HttpSession session = req.getSession();
			
			boolean f = uDao.UserRegister(user);
			
			//Success/Failure Validators
			if(f) {
				session.setAttribute("sucMsg", "Information Saved");
				resp.sendRedirect("signup.jsp");
				
			}
			else {
				
				session.setAttribute("errMsg", "Something Went Wrong");
				resp.sendRedirect("signup.jsp");
				
			}
		} 
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
