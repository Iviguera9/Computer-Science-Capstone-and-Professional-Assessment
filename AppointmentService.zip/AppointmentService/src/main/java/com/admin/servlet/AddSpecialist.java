// Function to Add Specialist(Specialty)
package com.admin.servlet;

import java.io.IOException; 

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.SpecialistDao;
import com.database.DBConnect;
import com.entity.User;

@WebServlet("/addSpecialist")
public class AddSpecialist extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String specialistName = req.getParameter("specialistName");
		
		SpecialistDao dao = new SpecialistDao(DBConnect.getDbs());
		boolean f = dao.addSpecialist(specialistName);
		
		HttpSession session = req.getSession();
		
		//Success/Failure Validators
		if (f) {
			session.setAttribute("sucMsg", "Information Saved");
			resp.sendRedirect("admin/index.jsp");
		}
		else {
			session.setAttribute("errMsg", "Something Went Wrong");
			resp.sendRedirect("admin/index.jsp");
		}
	
	
	}
}
